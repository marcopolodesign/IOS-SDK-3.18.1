//
//  OTAFramework.h
//  OTAFramework
//
//  Created by BlackMac on 2017/12/1.
//  Copyright © 2017年 HunterSun. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OTAFramework.
FOUNDATION_EXPORT double OTAFrameworkVersionNumber;

//! Project version string for OTAFramework.
FOUNDATION_EXPORT const unsigned char OTAFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OTAFramework/PublicHeader.h>

#import "OTALib.h"
